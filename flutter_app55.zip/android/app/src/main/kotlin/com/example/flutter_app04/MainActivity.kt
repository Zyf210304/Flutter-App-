package com.example.flutter_app04

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
