import 'package:flutter/material.dart';
import 'package:package_info_plus/package_info_plus.dart';
import 'package:path_provider/path_provider.dart';
import 'dart:io';
import 'package:open_filex/open_filex.dart';
import 'package:dio/dio.dart';
import 'package:permission_handler/permission_handler.dart';

class AppVersionPage extends StatefulWidget {
  const AppVersionPage({super.key});

  @override
  State<AppVersionPage> createState() => _AppVersionPageState();
}

class _AppVersionPageState extends State<AppVersionPage> {
  @override
  void initState() {
    // TODO: implement initState
    super.initState();
    this._getPackageInfo();
    this._getAppPath();
  }

  //弹出Dialog  备用
  void _showDialog() async {
    await showDialog(
        context: context,
        builder: (context) {
          return AlertDialog(
            title: const Text("更新APP提示!"),
            content: const Text("发现新的版本，新版本修复了如下bug 是否更新!"),
            actions: <Widget>[
              ElevatedButton(
                child: const Text("否"),
                onPressed: () {
                  Navigator.pop(context, 'Cancle');
                },
              ),
              ElevatedButton(
                child: const Text("是"),
                onPressed: () {
                  Navigator.pop(context, 'Ok');
                },
              )
            ],
          );
        });
  }

  //获取版本号
  _getPackageInfo() async {
    PackageInfo packageInfo = await PackageInfo.fromPlatform();
    String appName = packageInfo.appName;
    String packageName = packageInfo.packageName;
    String version = packageInfo.version;
    String buildNumber = packageInfo.buildNumber;

    print("appName:$appName");
    print("packageName:$packageName");
    print("version:$version");
    print("buildNumber:$buildNumber");
  }

//获取路径
  _getAppPath() async {
    Directory tempDir = await getTemporaryDirectory();
    String tempPath = tempDir.path;

    Directory appDocDir = await getApplicationDocumentsDirectory();
    String appDocPath = appDocDir.path;

    Directory? directory = await getExternalStorageDirectory();
    String storageDirectory = directory!.path;

    print("tempPath:$tempPath");
    print("appDocDir:$appDocPath");
    print("StorageDirectory:$storageDirectory");
  }

  //检查权限
  Future<bool> _checkPermission() async {
    if (Theme.of(context).platform == TargetPlatform.android) {
      final status = await Permission.storage.status;
      if (status != PermissionStatus.granted) {
        final result = await Permission.storage.request();
        if (result == PermissionStatus.granted) {
          return true;
        }
      } else {
        return true;
      }     
    }
     return false;
  }

  //下载打开文件
  _downLoad() async {
    var permission=await this._checkPermission();
    if(permission){
      final directory = await getExternalStorageDirectory();
      String localPath = directory!.path;
      String appName = "aaa.apk";
      String savePath="$localPath/$appName";

      String apkUrl = "https://jd.itying.com/jdshop.apk"; 
     
      ///参数一 文件的网络储存URL
      ///参数二 下载的本地目录文件
      ///参数三 下载监听
      Dio dio = Dio();
      await dio.download(apkUrl,savePath,
          onReceiveProgress: (received, total) {
            if (total != -1) {
              ///当前下载的百分比例
              print((received / total * 100).toStringAsFixed(0) + "%");        
            }
      });   
      print(savePath);
      await OpenFilex.open(savePath,type: "application/vnd.android.package-archive");
    }else{
      print("没有权限");
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      floatingActionButton: FloatingActionButton(       
        onPressed: _downLoad,
        child: const Icon(Icons.arrow_downward),
      ),
      appBar: AppBar(
        title: const Text("app升级演示"),
      ),
      body: const Text("app升级演示"),
    );
  }
}
